﻿using System;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.WebSockets;

namespace FinalProject
{
    public class Puzzle
    {
        private int[,] matrix = new int[3, 3];

        public delegate void loadGame(int[,] matrix, int counter);
        public event loadGame LoadGame;
        public delegate void movesDelegate(int moves);
        public event movesDelegate MovesFound;

        public void OnLoadGame(int[,] matrix, int counter)
        {
            if (LoadGame != null)
            {
                LoadGame(matrix,counter);
            }
        }

        private void OnMovesFound(int moves)
        {
            if(MovesFound!=null)
            {
                MovesFound(moves);
            }
        }

        private int count = 0;

        public int[,] setGame()
        {
            int inv = 1;
            int max = 3;
            do
            {
                int pos = 0;
                Random random = new Random();
                var a = Enumerable.Range(1, 9).OrderBy(c => random.Next()).ToArray();
                for (int i = 0; i < max; i++)
                {
                    for (int j = 0; j < max; j++)
                    {
                        matrix[i, j] = a[pos];
                        pos++;

                    }
                }
                inv = MatrixInv(matrix);
                Console.WriteLine("Inversiones: " + inv);
            } while (inv % 2 != 0);

                return matrix;
        }

        public int[,] Play(string[] spot)
        {
            int row = Convert.ToInt32(spot[0]);
            int col = Convert.ToInt32(spot[1]);

            if (row < 2 && matrix[row + 1, col] == 9)
            {
                matrix[row + 1, col] = matrix[row, col];
                matrix[row, col] = 9;
            }
            if (row > 0 && matrix[row - 1, col] == 9)
            {
                matrix[row - 1, col] = matrix[row, col];
                matrix[row, col] = 9;
            }
            if (col < 2 && matrix[row, col + 1] == 9)
            {
                matrix[row, col + 1] = matrix[row, col];
                matrix[row, col] = 9;
            }
            if (col > 0 && matrix[row, col - 1] == 9)
            {
                matrix[row, col - 1] = matrix[row, col];
                matrix[row, col] = 9;
            }
            return matrix;

        }

        public void gameCheck()
        {
            int cnt = 1;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (matrix[i, j] == cnt)
                    { cnt++; }
                    else { return;
                    }
                }
                if (cnt == 10)
                {
                    Console.WriteLine("Congrats! You made it in " + count + " moves!");
                    OnMovesFound(count);
                }
            }
        }
        public void Save(string filename)
        {
            try
            {
                StreamWriter sw = new StreamWriter(filename);
                var line = string.Empty;
                for(int i=0;i<3;i++)
                {
                    for(int j=0;j<3;j++)
                    {
                        line = line + ":" + matrix[i, j];
                    }
                }
                line = line + "," + count;
                sw.WriteLine(line);
                sw.Close();

            }
            catch(Exception ex)
            {
                Console.WriteLine("Error!", ex.Message);
            }
        }

        public void Load(string filename)
        {
            string[] lines = File.ReadAllLines(filename);
            var line = lines[0];
            var components = line.Split(',');
            var puzzle=components[0].Split(':');
            count = Convert.ToInt32(components[1]);
            int cnt = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(puzzle[cnt+1]);
                    cnt++;
                }
            }
            OnLoadGame(matrix, count);
        }

        private int MatrixInv(int[,] matrix)
        {
            int var;
            int inversion = 0;
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    for (int i2 = i; i2 < 3; i2++)
                    {
                        if (i2 > i)
                        {
                            var = 0;
                        }
                        else
                        {
                            var = j;
                        }
                        for (int j2 = var; j2 < 3; j2++)
                        {
                            if ((matrix[i, j] > matrix[i2, j2]) && ((matrix[i2, j2] != 0) && (matrix[i, j] != 0)))
                            {
                                inversion++;
                            }
                        }
                    }
                }
            }
            return inversion;
        }

        public int counter()
        {
            count = count + 1;
            return count;
        }
    }

}
