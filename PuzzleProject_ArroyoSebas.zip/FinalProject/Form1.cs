﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject
{



    public partial class Form1 : Form
    {
        Puzzle game;

        public void EmptyButton(Button button)
        {
            if (button.Text == "9" || button.Text == "0")
            {
                button.Text = " ";
            }
        }

        private void ButtonsNumber(int[,] matrix)
        {
            button1.Text = Convert.ToString(matrix[0, 0]);
            EmptyButton(button1);
            button2.Text = Convert.ToString(matrix[0, 1]);
            EmptyButton(button2);
            button3.Text = Convert.ToString(matrix[0, 2]);
            EmptyButton(button3);
            button4.Text = Convert.ToString(matrix[1, 0]);
            EmptyButton(button4);
            button5.Text = Convert.ToString(matrix[1, 1]);
            EmptyButton(button5);
            button6.Text = Convert.ToString(matrix[1, 2]);
            EmptyButton(button6);
            button7.Text = Convert.ToString(matrix[2, 0]);
            EmptyButton(button7);
            button8.Text = Convert.ToString(matrix[2, 1]);
            EmptyButton(button8);
            button9.Text = Convert.ToString(matrix[2, 2]);
            EmptyButton(button9);
        }

        public Form1()
        {
            InitializeComponent();
            game = new Puzzle();
            game.MovesFound += Game_MovesFound;
            game.LoadGame += Game_LoadGame;
        }

        private void Game_LoadGame(int[,] matrix, int counter)
        {
            ButtonsNumber(matrix);
            txtMoves.Text = Convert.ToString(counter);
        }

        private void Game_MovesFound(int moves)
        {
            MessageBox.Show("Congrats! You made it in " + moves + " moves!");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {       
            txtMoves.Text = "0";
            ButtonsNumber(game.setGame());         
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!(sender is Button))
            { return; }
            var button = (Button)sender;
            counter(button);
            string[] spot = button.Tag.ToString().Split(',');
            ButtonsNumber(game.Play(spot));
            game.gameCheck();
            
        }
        private void counter(Button button)
        {
            if(button.Text!=" ")
            {
                txtMoves.Text = Convert.ToString(game.counter());
            }
            
        }

        private void saveGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                game.Save(saveFileDialog1.FileName);
            }
        }

        private void loadGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Console.WriteLine("Nombre:"+openFileDialog1.FileName);
                game.Load(openFileDialog1.FileName);
            }
        }
    }
}
